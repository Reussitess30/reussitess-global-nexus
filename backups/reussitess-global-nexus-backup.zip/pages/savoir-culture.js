export default function SavoirCulture() {
  return (
    <div>
      <h1>Savoir & Culture</h1>
      <p>Page en construction...</p>
    </div>
  )
}
