export default function Outils() {
  return (
    <div className="container">
      <h1>🛠️ Outils & Calculateurs</h1>
      <p>Page en construction...</p>
      <a href="/">← Retour à l'accueil</a>
    </div>
  )
}
