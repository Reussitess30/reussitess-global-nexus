'use client'
export default function AntiCopyProtection() {
  return null
}
