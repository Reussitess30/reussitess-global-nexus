export default function BotAssistant() {
  return (
    <div style={{ display: 'none' }}>
      {/* Bot IA désactivé pour l'instant */}
    </div>
  )
}
